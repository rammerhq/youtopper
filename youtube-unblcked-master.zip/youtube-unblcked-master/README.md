### Use to get around blocked YouTube videos ;)

Find the finished product [here](https://yt.jcwyt.com).

Credit to DuckDuckGo for some of the `<iframe>` code
